﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace QLTK.Models
{
    [Table("TaiKhoan")]
    public class TaiKhoan
    {
        [Key, StringLength(10)]
        public string STK { get; set; } = null!;

        [Required, StringLength(150)]
        public string TenNH { get; set; } = null!;

        [Column(TypeName = "decimal(18,0)")]
        public decimal SoDuDauKy { get; set; }

        public virtual ICollection<GiaoDich> GiaoDiches { get; set; } = new List<GiaoDich>();
    }
}