﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace QLTK.Models
{
    [Table("GiaoDich")]
    public class GiaoDich
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public int SoTien { get; set; }

        [StringLength(255)]
        public string? NoiDung { get; set; }

        [Required, StringLength(10)]
        public string STK { get; set; } = null!;

        [ForeignKey("STK")]
        public virtual TaiKhoan TaiKhoan { get; set; } = null!;
    }
}