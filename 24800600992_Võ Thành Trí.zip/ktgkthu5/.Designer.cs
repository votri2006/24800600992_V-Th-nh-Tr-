﻿namespace ktgkthu5
{
    partial class frmQuanLyGiaoDich
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            dataGridView1 = new DataGridView();
            dataGridView2 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            button1 = new Button();
            menuStrip1 = new MenuStrip();
            chứcNăngToolStripMenuItem = new ToolStripMenuItem();
            cácGiaoDịchGửiTiềnToolStripMenuItem = new ToolStripMenuItem();
            sốDưCuốiKỳToolStripMenuItem = new ToolStripMenuItem();
            xuấtBáoCáoToolStripMenuItem = new ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(573, 73);
            label1.Name = "label1";
            label1.Size = new Size(223, 32);
            label1.TabIndex = 0;
            label1.Text = "Thông tin giao dịch";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(67, 117);
            label2.Name = "label2";
            label2.Size = new Size(223, 32);
            label2.TabIndex = 1;
            label2.Text = "Thông tin giao dịch";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(67, 185);
            label3.Name = "label3";
            label3.Size = new Size(75, 32);
            label3.TabIndex = 2;
            label3.Text = "Số TK";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(67, 257);
            label4.Name = "label4";
            label4.Size = new Size(47, 32);
            label4.TabIndex = 2;
            label4.Text = "GD";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(67, 336);
            label5.Name = "label5";
            label5.Size = new Size(89, 32);
            label5.TabIndex = 2;
            label5.Text = "Số tiền";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(41, 427);
            label6.Name = "label6";
            label6.Size = new Size(115, 32);
            label6.TabIndex = 2;
            label6.Text = "Nội dung";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(169, 177);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(242, 40);
            comboBox1.TabIndex = 3;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(169, 249);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(242, 40);
            comboBox2.TabIndex = 3;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(169, 333);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(200, 39);
            textBox1.TabIndex = 4;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(151, 427);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.Size = new Size(443, 254);
            dataGridView1.TabIndex = 5;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(151, 420);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.ScrollBars = ScrollBars.Vertical;
            textBox2.Size = new Size(443, 150);
            textBox2.TabIndex = 5;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4 });
            dataGridView2.Location = new Point(613, 142);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 82;
            dataGridView2.Size = new Size(927, 646);
            dataGridView2.TabIndex = 6;
            dataGridView2.CellContentClick += dataGridView2_CellContentClick;
            // 
            // Column1
            // 
            Column1.HeaderText = "ID";
            Column1.MinimumWidth = 10;
            Column1.Name = "Column1";
            Column1.Width = 200;
            // 
            // Column2
            // 
            Column2.HeaderText = "loại GD";
            Column2.MinimumWidth = 10;
            Column2.Name = "Column2";
            Column2.Width = 211;
            // 
            // Column3
            // 
            Column3.HeaderText = "Số Tiền";
            Column3.MinimumWidth = 10;
            Column3.Name = "Column3";
            Column3.Width = 210;
            // 
            // Column4
            // 
            Column4.HeaderText = "Nội Dung";
            Column4.MinimumWidth = 10;
            Column4.Name = "Column4";
            Column4.Width = 300;
            // 
            // button1
            // 
            button1.Location = new Point(151, 701);
            button1.Name = "button1";
            button1.Size = new Size(150, 46);
            button1.TabIndex = 7;
            button1.Text = "Thêm";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(32, 32);
            menuStrip1.Items.AddRange(new ToolStripItem[] { chứcNăngToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1552, 40);
            menuStrip1.TabIndex = 8;
            menuStrip1.Text = "menuStrip1";
            // 
            // chứcNăngToolStripMenuItem
            // 
            chứcNăngToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cácGiaoDịchGửiTiềnToolStripMenuItem, sốDưCuốiKỳToolStripMenuItem, xuấtBáoCáoToolStripMenuItem });
            chứcNăngToolStripMenuItem.Name = "chứcNăngToolStripMenuItem";
            chứcNăngToolStripMenuItem.Size = new Size(149, 36);
            chứcNăngToolStripMenuItem.Text = "Chức năng";
            // 
            // cácGiaoDịchGửiTiềnToolStripMenuItem
            // 
            cácGiaoDịchGửiTiềnToolStripMenuItem.Name = "cácGiaoDịchGửiTiềnToolStripMenuItem";
            cácGiaoDịchGửiTiềnToolStripMenuItem.Size = new Size(375, 44);
            cácGiaoDịchGửiTiềnToolStripMenuItem.Text = "các giao dịch gửi tiền";
            // 
            // sốDưCuốiKỳToolStripMenuItem
            // 
            sốDưCuốiKỳToolStripMenuItem.Name = "sốDưCuốiKỳToolStripMenuItem";
            sốDưCuốiKỳToolStripMenuItem.Size = new Size(375, 44);
            sốDưCuốiKỳToolStripMenuItem.Text = "Số dư cuối kỳ ";
            // 
            // xuấtBáoCáoToolStripMenuItem
            // 
            xuấtBáoCáoToolStripMenuItem.Name = "xuấtBáoCáoToolStripMenuItem";
            xuấtBáoCáoToolStripMenuItem.Size = new Size(375, 44);
            xuấtBáoCáoToolStripMenuItem.Text = "xuất báo cáo";
            // 
            // frmQuanLyGiaoDich
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1552, 800);
            Controls.Add(button1);
            Controls.Add(dataGridView2);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "frmQuanLyGiaoDich";
            Text = "frmQuanLyGiaoDich";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private TextBox textBox1;
        private TextBox textBox2;
        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private Button button1;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem chứcNăngToolStripMenuItem;
        private ToolStripMenuItem cácGiaoDịchGửiTiềnToolStripMenuItem;
        private ToolStripMenuItem sốDưCuốiKỳToolStripMenuItem;
        private ToolStripMenuItem xuấtBáoCáoToolStripMenuItem;
    }
}
