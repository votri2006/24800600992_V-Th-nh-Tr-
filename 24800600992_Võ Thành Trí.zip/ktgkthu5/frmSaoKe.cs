﻿using QLTK;
using QLTK.Models;

namespace ktgkthu5
{
    public partial class frmSaoKe : Form
    {
        // comboBox1 = Số TK, button1 = Xem, label3 = dòng "tài khoản:", dataGridView1 = lưới Id/Số Tiền/Nội dung

        public frmSaoKe()
        {
            InitializeComponent();
            this.Load += frmSaoKe_Load;   // gán bằng code, không double-click form trong Designer
        }

        // Nạp tất cả tài khoản vào ComboBox
        private void frmSaoKe_Load(object? sender, EventArgs e)
        {
            using var db = new QLTKContext();

            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.DataSource = db.TaiKhoans.OrderBy(t => t.STK).Select(t => t.STK).ToList();

            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.ReadOnly = true;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        // Nút Xem: tên ngân hàng, số tài khoản và các giao dịch của tài khoản đó
        private void button1_Click(object sender, EventArgs e)
        {
            string stk = comboBox1.Text;
            if (string.IsNullOrEmpty(stk)) return;

            using var db = new QLTKContext();

            string tenNH = db.TaiKhoans.Where(t => t.STK == stk)
                                       .Select(t => t.TenNH)
                                       .FirstOrDefault() ?? "";

            label3.Text = $"Tài khoản: {stk} - {tenNH}";

            var ds = db.GiaoDiches.Where(g => g.STK == stk).OrderBy(g => g.Id).ToList();

            dataGridView1.Rows.Clear();
            foreach (var g in ds)
            {
                // Thứ tự cột: Id, Số Tiền (giữ nguyên dấu, rút là số âm), Nội dung
                dataGridView1.Rows.Add(g.Id, g.SoTien, g.NoiDung);
            }
        }

        // Hàm rỗng đã được Designer gán sẵn (giữ lại để không lỗi biên dịch)
        private void label3_Click(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
    }
}
