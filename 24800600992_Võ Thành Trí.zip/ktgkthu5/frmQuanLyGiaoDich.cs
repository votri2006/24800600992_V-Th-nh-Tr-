using QLTK;
using QLTK.Models;
using System.Text;

namespace ktgkthu5
{
    public partial class frmQuanLyGiaoDich : Form
    {
        public frmQuanLyGiaoDich()
        {
            InitializeComponent();

            comboBox2.Items.AddRange(new object[] { "Gửi tiền", "Rút tiền" });
            comboBox2.SelectedIndex = 0;
            cácGiaoDịchGửiTiềnToolStripMenuItem.Click += cácGiaoDịchGửiTiềnToolStripMenuItem_Click;
            sốDưCuốiKỳToolStripMenuItem.Click += sốDưCuốiKỳToolStripMenuItem_Click;
            xuấtBáoCáoToolStripMenuItem.Click += xuấtBáoCáoToolStripMenuItem_Click;
            NapDuLieu();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var stk = comboBox1.SelectedValue?.ToString();
            if (string.IsNullOrWhiteSpace(stk))
            {
                MessageBox.Show("Vui lòng chọn số tài khoản.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                comboBox1.Focus();
                return;
            }

            if (!int.TryParse(textBox1.Text.Trim(), out var soTien) || soTien < 1 || soTien > 100000000)
            {
                MessageBox.Show("Vui lòng nhập số tiền từ 1-100000000!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                return;
            }

            if (comboBox2.SelectedIndex < 0)
            {
                MessageBox.Show("Vui lòng chọn loại giao dịch.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                comboBox2.Focus();
                return;
            }

            var noiDung = textBox2.Text.Trim();
            if (string.IsNullOrWhiteSpace(noiDung))
            {
                MessageBox.Show("Vui lòng nhập nội dung giao dịch.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.Focus();
                return;
            }

            var giaTriGiaoDich = comboBox2.SelectedIndex == 0 ? soTien : -soTien;

            try
            {
                using var db = new QLTKContext();
                var taiKhoan = db.TaiKhoans.SingleOrDefault(t => t.STK == stk);
                if (taiKhoan == null)
                {
                    MessageBox.Show("Số tài khoản không tồn tại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    NapTaiKhoan(db);
                    return;
                }

                if (comboBox2.SelectedIndex == 1)
                {
                    var soDuCuoiKy = taiKhoan.SoDuDauKy
                        + (db.GiaoDiches
                            .Where(g => g.STK == stk)
                            .Select(g => (decimal?)g.SoTien)
                            .Sum() ?? 0);

                    if (soTien > soDuCuoiKy)
                    {
                        MessageBox.Show("Tài khoản không đủ số tiền để rút!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        textBox1.Focus();
                        return;
                    }
                }

                db.GiaoDiches.Add(new GiaoDich
                {
                    STK = stk,
                    SoTien = giaTriGiaoDich,
                    NoiDung = noiDung
                });
                db.SaveChanges();

                // Hiển thị lại toàn bộ giao dịch, kể cả khi lưới đang được lọc.
                HienThiLuoi(db.GiaoDiches.OrderBy(g => g.Id).ToList());
                DatLaiThongTinGiaoDich();
                MessageBox.Show("Thêm mới giao dịch thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Không thể thêm giao dịch: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DatLaiThongTinGiaoDich()
        {
            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }

            comboBox2.SelectedIndex = 0;
            textBox1.Clear();
            textBox2.Clear();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void NapDuLieu()
        {
            try
            {
                using var db = new QLTKContext();
                db.Database.EnsureCreated();
                NapTaiKhoan(db);
                HienThiLuoi(db.GiaoDiches.OrderBy(g => g.Id).ToList());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Không thể tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void NapTaiKhoan(QLTKContext db)
        {
            var taiKhoans = db.TaiKhoans.OrderBy(t => t.STK).ToList();
            comboBox1.DataSource = taiKhoans;
            comboBox1.DisplayMember = nameof(TaiKhoan.STK);
            comboBox1.ValueMember = nameof(TaiKhoan.STK);
        }

        private void HienThiLuoi(IEnumerable<GiaoDich> giaoDiches)
        {
            dataGridView2.Rows.Clear();
            foreach (var giaoDich in giaoDiches)
            {
                dataGridView2.Rows.Add(
                    giaoDich.Id,
                    giaoDich.STK,
                    giaoDich.SoTien,
                    giaoDich.NoiDung ?? string.Empty);
            }
        }
        private void cácGiaoDịchGửiTiềnToolStripMenuItem_Click(object sender, EventArgs e)   // F1
        {
            using var db = new QLTKContext();
            HienThiLuoi(db.GiaoDiches.Where(g => g.SoTien > 0).OrderBy(g => g.Id).ToList());
        }

        private void sốDưCuốiKỳToolStripMenuItem_Click(object sender, EventArgs e)           // F2
        {
            using var db = new QLTKContext();
            var sb = new StringBuilder("Số dư cuối kỳ:" + Environment.NewLine);
            int i = 1;

            foreach (var tk in db.TaiKhoans.OrderBy(t => t.STK).ToList())
            {
                decimal tong = db.GiaoDiches.Where(g => g.STK == tk.STK).Sum(g => (int?)g.SoTien) ?? 0;
                sb.AppendLine($"{i++}. TK {tk.STK} - SDCK: {tk.SoDuDauKy + tong:0}");
            }

            MessageBox.Show(sb.ToString(), "Số dư cuối kỳ");
        }

        private void xuấtBáoCáoToolStripMenuItem_Click(object sender, EventArgs e)           // Ctrl+R
        {
            // Chưa làm Câu 6 thì tạm đặt // trước dòng dưới để không báo lỗi
            new frmSaoKe().ShowDialog(this);
        }
    }
}
